import sys
import subprocess
def main():
	logfile = open("/tmp/mkvmerge_log.txt", "w")
	argv = sys.argv
	if len(argv) == 1:
		print "No input provided"
	else:
		infile = '';
		cubefile = '';
		if len(argv) == 2:
			logfile.write("Input is: " + argv[1] + "\n")
			infile = argv[1]
		elif len(argv) == 3:
			_, ext = os.path.splitext(argv[1])
			if(ext == '.cube'):
				cubefile = argv[1]
				infile = argv[2]
			else:
				cubefile = argv[2]
				infile = argv[1]
		logfile.write("Input video is: " + infile + "\n")
		logfile.write("LUT file is: " + cubefile + "\n")

		pq_outfile = '.'.join(infile.split('.')[:-1]) + '_PQ.mkv'
		hlg_outfile = '.'.join(infile.split('.')[:-1]) + '_HLG.mkv'
		cmd = ['../Resources/mkvmerge', '-o', pq_outfile,
				'--colour-matrix', '0:9',
				'--colour-range', '0:1',
				'--colour-transfer-characteristics', '0:16',
				'--colour-primaries', '0:9',
				'--max-content-light','0:1000',
				'--max-frame-light', '0:300',
				'--max-luminance', '0:1000',
				'--min-luminance', '0:0.01',
				'--chromaticity-coordinates',
				'0:0.68,0.32,0.265,0.690,0.15,0.06',
				'--white-colour-coordinates',
				'0:0.3127,0.3290']
		if cubefile:
			cmd.append('--attachment-mime-type')
			cmd.append('application/x-cube')
			cmd.append('--attach-file')
			cmd.append(cubefile)
		cmd.append(infile)
		logfile.write("Command is: " + ' '.join(cmd))
		try:
			subprocess.check_output(cmd, stderr=subprocess.STDOUT)
		except subprocess.CalledProcessError as error:
			logfile.write("Command: " + ' '.join(cmd) + " failed")
		cmd = ['../Resources/mkvmerge', '-o', hlg_outfile,
				'--colour-matrix', '0:9',
				'--colour-range', '0:1',
				'--colour-transfer-characteristics', '0:18',
				'--colour-primaries', '0:9',
				'--max-content-light','0:1000',
				'--max-frame-light', '0:300',
				'--max-luminance', '0:1000',
				'--min-luminance', '0:0.01',
				'--chromaticity-coordinates',
				'0:0.68,0.32,0.265,0.690,0.15,0.06',
				'--white-colour-coordinates',
				'0:0.3127,0.3290']
		if cubefile:
			cmd.append('--attachment-mime-type')
			cmd.append('application/x-cube')
			cmd.append('--attach-file')
			cmd.append(cubefile)
		cmd.append(infile)
		try:
			subprocess.check_output(cmd, stderr=subprocess.STDOUT)
			logfile.write("Command is: " + ' '.join(cmd))
		except subprocess.CalledProcessError as error:
			logfile.write("Command: " + ' '.join(cmd) + " failed")
	logfile.close()


if __name__ == "__main__":
	main()

