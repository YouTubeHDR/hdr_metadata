import sys
import subprocess
import os
import shutil
def main():
	logfile = open("/tmp/mkvmerge_log.txt", "w")
	argv = sys.argv
	if len(argv) == 1:
		print "No input provided"
	else:
		infile = '';
		cubefile = '';
		if len(argv) == 2:
			logfile.write("Input is: " + argv[1] + "\n")
			infile = argv[1]
		elif len(argv) == 3:
			_, ext = os.path.splitext(argv[1])
			if(ext == '.cube'):
				cubefile = argv[1]
				infile = argv[2]
			else:
				cubefile = argv[2]
				infile = argv[1]
		logfile.write("Input video is: " + infile + "\n")
		logfile.write("LUT file is: " + cubefile + "\n")
		# check if the input video is HDR

		pq_outfile = '.'.join(infile.split('.')[:-1]) + '_PQ.mkv'
		logfile.write("pq_out file is: " + pq_outfile + "\n")
		hlg_outfile = '.'.join(infile.split('.')[:-1]) + '_HLG.mkv'
		tmp_pq_file = "/tmp/pq.mkv"
		tmp_hlg_file = "/tmp/hlg.mkv"
		cmd = ['../Resources/mkvmerge', '-o', tmp_pq_file,
				'--colour-matrix', '0:9',
				'--colour-range', '0:1',
				'--colour-transfer-characteristics', '0:16',
				'--colour-primaries', '0:9',
				'--max-content-light','0:1000',
				'--max-frame-light', '0:300',
				'--max-luminance', '0:1000',
				'--min-luminance', '0:0.01',
				'--chromaticity-coordinates',
				'0:0.68,0.32,0.265,0.690,0.15,0.06',
				'--white-colour-coordinates',
				'0:0.3127,0.3290']
		if cubefile:
			cmd.append('--attachment-mime-type')
			cmd.append('application/x-cube')
			cmd.append('--attach-file')
			cmd.append(cubefile)
		cmd.append(infile)
		logfile.write("Command is: " + ' '.join(cmd) + "\n")
		try:
			subprocess.check_output(cmd, stderr=subprocess.STDOUT)
		except subprocess.CalledProcessError as error:
			logfile.write("Command: " + ' '.join(cmd) + " failed")
		cmd = ['../Resources/mkvmerge', '-o', tmp_hlg_file,
				'--colour-matrix', '0:9',
				'--colour-range', '0:1',
				'--colour-transfer-characteristics', '0:18',
				'--colour-primaries', '0:9',
				'--max-content-light','0:1000',
				'--max-frame-light', '0:300',
				'--max-luminance', '0:1000',
				'--min-luminance', '0:0.01',
				'--chromaticity-coordinates',
				'0:0.68,0.32,0.265,0.690,0.15,0.06',
				'--white-colour-coordinates',
				'0:0.3127,0.3290']
		if cubefile:
			cmd.append('--attachment-mime-type')
			cmd.append('application/x-cube')
			cmd.append('--attach-file')
			cmd.append(cubefile)
		cmd.append(infile)
		try:
			subprocess.check_output(cmd, stderr=subprocess.STDOUT)
			logfile.write("Command is: " + ' '.join(cmd) + "\n")
		except subprocess.CalledProcessError as error:
			logfile.write("Command: " + ' '.join(cmd) + " failed")
		if os.path.isfile("/tmp/PQ.txt"):
			logfile.write("Input file is PQ already\n")
			logfile.write("moving " + tmp_pq_file + " to: " + pq_outfile + '\n')
			shutil.move(tmp_pq_file, pq_outfile)
			logfile.write("Only output PG version.\n")
			os.remove(tmp_hlg_file)
			logfile.write("delete HLG version.\n")
			os.remove("/tmp/PQ.txt")
		elif os.path.isfile("/tmp/HLG.txt"):
			logfile.write("Input file is HLG already\n")
			shutil.move(tmp_hlg_file, hlg_outfile)
			logfile.write("Only output HLG version.\n")
			os.remove(tmp_pq_file)
			logfile.write("remove PG version.\n")
			os.remove("/tmp/HLG.txt")
		else:
			shutil.move(tmp_pq_file, pq_outfile)
			shutil.move(tmp_hlg_file, hlg_outfile)
	logfile.close()


if __name__ == "__main__":
	main()

