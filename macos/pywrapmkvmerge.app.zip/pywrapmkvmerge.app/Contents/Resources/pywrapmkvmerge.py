import sys
import subprocess
def main():
	logfile = open("/tmp/mkvmerge_log.txt", "w")
	argv = sys.argv
	if len(argv) == 1:
		print "No input provided"
	else:
		logfile.write("Input is: " + argv[1] + "\n")
		infile = argv[1]
		pq_outfile = '.'.join(argv[1].split('.')[:-1]) + '_PQ.mkv'
		hlg_outfile = '.'.join(argv[1].split('.')[:-1]) + '_HLG.mkv'
		cmd = ['../Resources/mkvmerge', '-o', pq_outfile,
				'--colour-matrix', '0:9',
				'--colour-range', '0:1',
				'--colour-transfer-characteristics', '0:16',
				'--colour-primaries', '0:9',
				'--max-content-light','0:1000',
				'--max-frame-light', '0:300',
				'--max-luminance', '0:1000',
				'--min-luminance', '0:0.01',
				'--chromaticity-coordinates',
				'0:0.68,0.32,0.265,0.690,0.15,0.06',
				'--white-colour-coordinates',
				'0:0.3127,0.3290',
				infile]
		try:
			subprocess.check_output(cmd, stderr=subprocess.STDOUT)
		except subprocess.CalledProcessError as error:
			logfile.write("Command: " + ' '.join(cmd) + " failed")
		cmd = ['../Resources/mkvmerge', '-o', hlg_outfile,
				'--colour-matrix', '0:9',
				'--colour-range', '0:1',
				'--colour-transfer-characteristics', '0:18',
				'--colour-primaries', '0:9',
				'--max-content-light','0:1000',
				'--max-frame-light', '0:300',
				'--max-luminance', '0:1000',
				'--min-luminance', '0:0.01',
				'--chromaticity-coordinates',
				'0:0.68,0.32,0.265,0.690,0.15,0.06',
				'--white-colour-coordinates',
				'0:0.3127,0.3290',
				infile]
		try:
			subprocess.check_output(cmd, stderr=subprocess.STDOUT)
		except subprocess.CalledProcessError as error:
			logfile.write("Command: " + ' '.join(cmd) + " failed")
	logfile.close()


if __name__ == "__main__":
	main()

